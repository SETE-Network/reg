def main():
    print('glob3 - main()')


if __name__ == '__main__':
    main()
